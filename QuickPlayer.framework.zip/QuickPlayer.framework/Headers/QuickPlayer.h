//
//  QuickPlayer.h
//  QuickPlayer
//
//  Created by Shvier on 31/03/2017.
//  Copyright © 2017 Shvier. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QuickPlayer.
FOUNDATION_EXPORT double QuickPlayerVersionNumber;

//! Project version string for QuickPlayer.
FOUNDATION_EXPORT const unsigned char QuickPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuickPlayer/PublicHeader.h>
